import logo from './logo.svg';
import './App.css';

function App() {

  const name = 'Nguyen Quang Duy';
  const age = '18';
  const job = 'Student';
  const favor = 'Football';

  return (
    <div>
      <p>Name: {name}</p>
      <p>Age: {age}</p>
      <p>Job: {job}</p>
      <p>Favor: {favor}</p>
    </div>
  );
}

export default App;
